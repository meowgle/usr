#!/bin/sh
docky
tint2

